## Analysis plan

| Stage | Plan |
|---|---|
| EDA | Shape and dtype, missing values, pixel range, class balance, duplicates / train-test leakage, blank images, sample grid, pixel histogram, mean image per class |
| Feature selection | CNN learns its own features, so no p-value elimination. Scale pixels to 0-1, add channel dimension, create validation split |
| Train model | 48k train / 12k validation / 10k test. 2 Conv blocks, Dense(64), Adam (lr 0.001), batch 64, 10 epochs, sparse categorical crossentropy |
| Evaluate | Accuracy, per-class precision / recall / F1, confusion matrix, loss and accuracy curves |
| Retrain | Add BatchNorm, Dropout, early stopping based on baseline diagnosis; compare in a table |
| Report | Cleaning, EDA, model training, interpretation and evaluation |

## 1. Load the dataset


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import tensorflow as tf
from tensorflow.keras import layers, models, callbacks
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score

# Fix random seeds so results are reproducible when re-run
np.random.seed(42)
tf.random.set_seed(42)

# Fashion-MNIST ships with Keras, so it is downloaded automatically on first run.
# It returns (training images, training labels), (test images, test labels)
(x_train_full, y_train_full), (x_test, y_test) = tf.keras.datasets.fashion_mnist.load_data()

# Labels are stored as numbers 0-9, so we map them to readable names
class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']
```

    Downloading data from https://storage.googleapis.com/tensorflow/tf-keras-datasets/train-labels-idx1-ubyte.gz
    [1m29515/29515[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 6us/step 
    Downloading data from https://storage.googleapis.com/tensorflow/tf-keras-datasets/train-images-idx3-ubyte.gz
    [1m26421880/26421880[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m9s[0m 0us/step
    Downloading data from https://storage.googleapis.com/tensorflow/tf-keras-datasets/t10k-labels-idx1-ubyte.gz
    [1m5148/5148[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 0us/step
    Downloading data from https://storage.googleapis.com/tensorflow/tf-keras-datasets/t10k-images-idx3-ubyte.gz
    [1m4422102/4422102[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 1us/step
    

## 2. Exploratory Data Analysis (EDA) and data cleaning checks

### 2.1 Structure of the data


```python
print("Training images:", x_train_full.shape)   # (60000, 28, 28) = 60k images of 28x28 pixels
print("Training labels:", y_train_full.shape)
print("Test images:    ", x_test.shape)         # (10000, 28, 28)
print("Test labels:    ", y_test.shape)
print("Image data type:", x_train_full.dtype)   # uint8 = whole numbers 0-255
# Greyscale, so there is 1 colour channel (no RGB dimension in the raw data)
```

    Training images: (60000, 28, 28)
    Training labels: (60000,)
    Test images:     (10000, 28, 28)
    Test labels:     (10000,)
    Image data type: uint8
    

### 2.2 Data quality: missing values and valid pixel range


```python
print("Missing values in train images:", np.isnan(x_train_full.astype(float)).sum())
print("Missing values in test images: ", np.isnan(x_test.astype(float)).sum())
print("Pixel min/max:", x_train_full.min(), "/", x_train_full.max())   # expect 0 / 255
print("Unique labels in train:", np.unique(y_train_full))              # expect 0-9 only
```

    Missing values in train images: 0
    Missing values in test images:  0
    Pixel min/max: 0 / 255
    Unique labels in train: [0 1 2 3 4 5 6 7 8 9]
    

### 2.3 Class balance


```python
# An imbalanced dataset could bias the model toward the larger classes
counts = pd.Series(y_train_full).map(dict(enumerate(class_names))).value_counts()
print(counts)

plt.figure(figsize=(10, 4))
sns.barplot(x=counts.index, y=counts.values, color="steelblue")
plt.xticks(rotation=45)
plt.title("Class distribution in the training set")
plt.ylabel("Number of images")
plt.tight_layout()
plt.show()
```

    Ankle boot     6000
    T-shirt/top    6000
    Dress          6000
    Pullover       6000
    Sneaker        6000
    Sandal         6000
    Trouser        6000
    Shirt          6000
    Coat           6000
    Bag            6000
    Name: count, dtype: int64
    


    
![png](output_9_1.png)
    


### 2.4 Duplicates and train/test leakage


```python
# Duplicates inflate the dataset; train/test overlap would make test scores unfairly high
train_hashes = [hash(img.tobytes()) for img in x_train_full]
test_hashes  = [hash(img.tobytes()) for img in x_test]
n_dups = len(train_hashes) - len(set(train_hashes))
n_leak = len(set(train_hashes) & set(test_hashes))
print("Duplicate images within training set:", n_dups)
print("Images appearing in both train and test:", n_leak)
```

    Duplicate images within training set: 0
    Images appearing in both train and test: 0
    

### 2.5 Blank or corrupt images


```python
# An image with almost no variation (one flat colour) carries no useful information
pixel_std = x_train_full.reshape(len(x_train_full), -1).std(axis=1)
print("Near-blank images (std < 1):", (pixel_std < 1).sum())
```

    Near-blank images (std < 1): 0
    

### 2.6 Visual inspection


```python
fig, axes = plt.subplots(10, 8, figsize=(12, 15))
for cls in range(10):
    idxs = np.where(y_train_full == cls)[0][:8]       # first 8 examples of each class
    for j, idx in enumerate(idxs):
        axes[cls, j].imshow(x_train_full[idx], cmap='gray')
        axes[cls, j].axis('off')
        if j == 0:
            axes[cls, j].set_title(class_names[cls], fontsize=9, loc='left')
plt.suptitle("8 sample images per class", y=1.0)
plt.tight_layout()
plt.show()
```


    
![png](output_15_0.png)
    


### 2.7 Pixel intensity distribution


```python
plt.figure(figsize=(8, 4))
plt.hist(x_train_full.flatten(), bins=50, color="grey")
plt.title("Distribution of pixel values (0 = black, 255 = white)")
plt.xlabel("Pixel value"); plt.ylabel("Count")
plt.yscale("log")   # log scale because the black background dominates
plt.show()
```


    
![png](output_17_0.png)
    


### 2.8 Mean image per class


```python
# Classes whose average images look alike are likely to be confused by the model
fig, axes = plt.subplots(2, 5, figsize=(12, 5))
for cls, ax in enumerate(axes.flatten()):
    ax.imshow(x_train_full[y_train_full == cls].mean(axis=0), cmap='gray')
    ax.set_title(class_names[cls]); ax.axis('off')
plt.suptitle("Mean image per class")
plt.show()
```


    
![png](output_19_0.png)
    


### 2.9 Average brightness per class


```python
brightness = pd.DataFrame({
    "class": [class_names[i] for i in y_train_full],
    "mean_pixel": x_train_full.reshape(len(x_train_full), -1).mean(axis=1)
})
plt.figure(figsize=(10, 4))
sns.boxplot(data=brightness, x="class", y="mean_pixel")
plt.xticks(rotation=45)
plt.title("Average pixel brightness per class")
plt.tight_layout()
plt.show()
```


    
![png](output_21_0.png)
    


**EDA findings (complete after running):** _Summarise: any missing values, duplicates or leakage found; whether classes are balanced; which classes look visually similar and are likely to be confused._

## 3. Preprocessing and feature preparation


```python
# Pixels run 0-255; neural networks train better on small values, so scale to 0-1
x_train_full = x_train_full / 255.0
x_test = x_test / 255.0
# Conv2D expects (height, width, channels). Greyscale = 1 channel
x_train_full = x_train_full[..., np.newaxis]
x_test = x_test[..., np.newaxis]

# Hold out 12,000 training images for validation (used to monitor overfitting during training)
x_train, y_train = x_train_full[:48000], y_train_full[:48000]
x_val,   y_val   = x_train_full[48000:], y_train_full[48000:]
print("train:", x_train.shape, "val:", x_val.shape, "test:", x_test.shape)
```

    train: (48000, 28, 28, 1) val: (12000, 28, 28, 1) test: (10000, 28, 28, 1)
    

## 4. Baseline CNN


```python
def build_baseline():
    return models.Sequential([
        layers.Conv2D(32, 3, activation='relu', input_shape=(28, 28, 1)),  # learns 32 small edge/texture detectors
        layers.MaxPooling2D(),                                             # halves the image size, keeps strongest signals
        layers.Conv2D(64, 3, activation='relu'),                           # learns combinations of the first features
        layers.MaxPooling2D(),
        layers.Flatten(),                                                  # turns feature maps into one vector
        layers.Dense(64, activation='relu'),                               # combines features for the decision
        layers.Dense(10, activation='softmax')                             # 10 class probabilities
    ])

base = build_baseline()
base.compile(optimizer=tf.keras.optimizers.Adam(0.001),
             loss='sparse_categorical_crossentropy', metrics=['accuracy'])
base.summary()
h1 = base.fit(x_train, y_train, epochs=10, batch_size=64, validation_data=(x_val, y_val))
```

    C:\Users\MSI 1\anaconda3\Lib\site-packages\keras\src\layers\convolutional\base_conv.py:113: UserWarning: Do not pass an `input_shape`/`input_dim` argument to a layer. When using Sequential models, prefer using an `Input(shape)` object as the first layer in the model instead.
      super().__init__(activity_regularizer=activity_regularizer, **kwargs)
    

    WARNING:tensorflow:TensorFlow GPU support is not available on native Windows for TensorFlow >= 2.11. Even if CUDA/cuDNN are installed, GPU will not be used. Please use WSL2 or the TensorFlow-DirectML plugin.
    


<pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold">Model: "sequential"</span>
</pre>




<pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace">┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━┓
┃<span style="font-weight: bold"> Layer (type)                    </span>┃<span style="font-weight: bold"> Output Shape           </span>┃<span style="font-weight: bold">       Param # </span>┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━┩
│ conv2d (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)                 │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">26</span>, <span style="color: #00af00; text-decoration-color: #00af00">26</span>, <span style="color: #00af00; text-decoration-color: #00af00">32</span>)     │           <span style="color: #00af00; text-decoration-color: #00af00">320</span> │
├─────────────────────────────────┼────────────────────────┼───────────────┤
│ max_pooling2d (<span style="color: #0087ff; text-decoration-color: #0087ff">MaxPooling2D</span>)    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">13</span>, <span style="color: #00af00; text-decoration-color: #00af00">13</span>, <span style="color: #00af00; text-decoration-color: #00af00">32</span>)     │             <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
├─────────────────────────────────┼────────────────────────┼───────────────┤
│ conv2d_1 (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)               │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">11</span>, <span style="color: #00af00; text-decoration-color: #00af00">11</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)     │        <span style="color: #00af00; text-decoration-color: #00af00">18,496</span> │
├─────────────────────────────────┼────────────────────────┼───────────────┤
│ max_pooling2d_1 (<span style="color: #0087ff; text-decoration-color: #0087ff">MaxPooling2D</span>)  │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">5</span>, <span style="color: #00af00; text-decoration-color: #00af00">5</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)       │             <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
├─────────────────────────────────┼────────────────────────┼───────────────┤
│ flatten (<span style="color: #0087ff; text-decoration-color: #0087ff">Flatten</span>)               │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1600</span>)           │             <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
├─────────────────────────────────┼────────────────────────┼───────────────┤
│ dense (<span style="color: #0087ff; text-decoration-color: #0087ff">Dense</span>)                   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)             │       <span style="color: #00af00; text-decoration-color: #00af00">102,464</span> │
├─────────────────────────────────┼────────────────────────┼───────────────┤
│ dense_1 (<span style="color: #0087ff; text-decoration-color: #0087ff">Dense</span>)                 │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">10</span>)             │           <span style="color: #00af00; text-decoration-color: #00af00">650</span> │
└─────────────────────────────────┴────────────────────────┴───────────────┘
</pre>




<pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold"> Total params: </span><span style="color: #00af00; text-decoration-color: #00af00">121,930</span> (476.29 KB)
</pre>




<pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold"> Trainable params: </span><span style="color: #00af00; text-decoration-color: #00af00">121,930</span> (476.29 KB)
</pre>




<pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold"> Non-trainable params: </span><span style="color: #00af00; text-decoration-color: #00af00">0</span> (0.00 B)
</pre>



    Epoch 1/10
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m24s[0m 28ms/step - accuracy: 0.8010 - loss: 0.5438 - val_accuracy: 0.8656 - val_loss: 0.3823
    Epoch 2/10
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m21s[0m 28ms/step - accuracy: 0.8719 - loss: 0.3612 - val_accuracy: 0.8838 - val_loss: 0.3265
    Epoch 3/10
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m21s[0m 27ms/step - accuracy: 0.8883 - loss: 0.3127 - val_accuracy: 0.8913 - val_loss: 0.3018
    Epoch 4/10
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m20s[0m 27ms/step - accuracy: 0.8987 - loss: 0.2802 - val_accuracy: 0.8957 - val_loss: 0.2921
    Epoch 5/10
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m21s[0m 28ms/step - accuracy: 0.9069 - loss: 0.2539 - val_accuracy: 0.8998 - val_loss: 0.2795
    Epoch 6/10
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m41s[0m 28ms/step - accuracy: 0.9156 - loss: 0.2309 - val_accuracy: 0.9009 - val_loss: 0.2778
    Epoch 7/10
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m21s[0m 28ms/step - accuracy: 0.9229 - loss: 0.2114 - val_accuracy: 0.9027 - val_loss: 0.2759
    Epoch 8/10
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m22s[0m 29ms/step - accuracy: 0.9293 - loss: 0.1935 - val_accuracy: 0.9036 - val_loss: 0.2730
    Epoch 9/10
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m21s[0m 27ms/step - accuracy: 0.9353 - loss: 0.1772 - val_accuracy: 0.9058 - val_loss: 0.2801
    Epoch 10/10
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m20s[0m 26ms/step - accuracy: 0.9413 - loss: 0.1620 - val_accuracy: 0.9031 - val_loss: 0.2927
    

## 5. Evaluate the baseline


```python
results = {}   # stores metrics so the two models can be compared in a table

def evaluate(model, history, name):
    # Learning curves: a growing gap between train and validation signals overfitting
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    ax[0].plot(history.history['accuracy'], label='train')
    ax[0].plot(history.history['val_accuracy'], label='validation')
    ax[0].set_title(name + " accuracy"); ax[0].set_xlabel("Epoch"); ax[0].legend()
    ax[1].plot(history.history['loss'], label='train')
    ax[1].plot(history.history['val_loss'], label='validation')
    ax[1].set_title(name + " loss"); ax[1].set_xlabel("Epoch"); ax[1].legend()
    plt.show()

    # Predictions on the unseen test set
    y_pred = np.argmax(model.predict(x_test), axis=1)
    print(classification_report(y_test, y_pred, target_names=class_names))

    # Confusion matrix: rows = actual class, columns = predicted class
    plt.figure(figsize=(8, 6))
    sns.heatmap(confusion_matrix(y_test, y_pred), annot=True, fmt='d',
                xticklabels=class_names, yticklabels=class_names, cmap='Blues')
    plt.xlabel("Predicted"); plt.ylabel("Actual"); plt.title(name + " confusion matrix")
    plt.show()

    results[name] = {
        "Test accuracy": accuracy_score(y_test, y_pred),
        "Macro F1": f1_score(y_test, y_pred, average='macro'),
        "Final train acc": history.history['accuracy'][-1],
        "Final val acc": history.history['val_accuracy'][-1],
        "Epochs run": len(history.history['loss']),
    }
    return y_pred

pred_base = evaluate(base, h1, "Baseline")
```


    
![png](output_28_0.png)
    


    [1m313/313[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 8ms/step
                  precision    recall  f1-score   support
    
     T-shirt/top       0.89      0.81      0.85      1000
         Trouser       1.00      0.97      0.98      1000
        Pullover       0.79      0.91      0.84      1000
           Dress       0.90      0.91      0.90      1000
            Coat       0.89      0.77      0.83      1000
          Sandal       0.99      0.95      0.97      1000
           Shirt       0.69      0.75      0.72      1000
         Sneaker       0.90      0.99      0.94      1000
             Bag       0.97      0.97      0.97      1000
      Ankle boot       0.98      0.93      0.96      1000
    
        accuracy                           0.90     10000
       macro avg       0.90      0.90      0.90     10000
    weighted avg       0.90      0.90      0.90     10000
    
    


    
![png](output_28_2.png)
    


## 6. Retrain with changes


```python
# Changes chosen to address overfitting seen in the baseline:
#  - BatchNormalization: stabilises and speeds up training
#  - Dropout: randomly switches off units so the model cannot memorise the training set
#  - Larger Dense layer: more capacity for the final decision
#  - EarlyStopping: stops when validation loss stops improving and restores the best weights
improved = models.Sequential([
    layers.Conv2D(32, 3, padding='same', activation='relu', input_shape=(28, 28, 1)),
    layers.BatchNormalization(),
    layers.MaxPooling2D(),
    layers.Dropout(0.25),
    layers.Conv2D(64, 3, padding='same', activation='relu'),
    layers.BatchNormalization(),
    layers.MaxPooling2D(),
    layers.Dropout(0.25),
    layers.Flatten(),
    layers.Dense(128, activation='relu'),
    layers.Dropout(0.4),
    layers.Dense(10, activation='softmax')
])
improved.compile(optimizer=tf.keras.optimizers.Adam(0.001),
                 loss='sparse_categorical_crossentropy', metrics=['accuracy'])
early = callbacks.EarlyStopping(monitor='val_loss', patience=3, restore_best_weights=True)
h2 = improved.fit(x_train, y_train, epochs=20, batch_size=64,
                  validation_data=(x_val, y_val), callbacks=[early])
pred_imp = evaluate(improved, h2, "Improved")
```

    C:\Users\MSI 1\anaconda3\Lib\site-packages\keras\src\layers\convolutional\base_conv.py:113: UserWarning: Do not pass an `input_shape`/`input_dim` argument to a layer. When using Sequential models, prefer using an `Input(shape)` object as the first layer in the model instead.
      super().__init__(activity_regularizer=activity_regularizer, **kwargs)
    

    Epoch 1/20
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m60s[0m 75ms/step - accuracy: 0.7965 - loss: 0.5669 - val_accuracy: 0.8768 - val_loss: 0.3521
    Epoch 2/20
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m52s[0m 70ms/step - accuracy: 0.8580 - loss: 0.3875 - val_accuracy: 0.8863 - val_loss: 0.3091
    Epoch 3/20
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m51s[0m 67ms/step - accuracy: 0.8781 - loss: 0.3354 - val_accuracy: 0.8986 - val_loss: 0.2808
    Epoch 4/20
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m52s[0m 69ms/step - accuracy: 0.8891 - loss: 0.3073 - val_accuracy: 0.9047 - val_loss: 0.2616
    Epoch 5/20
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m59s[0m 79ms/step - accuracy: 0.8931 - loss: 0.2934 - val_accuracy: 0.9027 - val_loss: 0.2769
    Epoch 6/20
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m61s[0m 81ms/step - accuracy: 0.9062 - loss: 0.2505 - val_accuracy: 0.9188 - val_loss: 0.2268
    Epoch 9/20
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m58s[0m 78ms/step - accuracy: 0.9109 - loss: 0.2392 - val_accuracy: 0.9110 - val_loss: 0.2551
    Epoch 11/20
    [1m750/750[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m60s[0m 80ms/step - accuracy: 0.9144 - loss: 0.2286 - val_accuracy: 0.8832 - val_loss: 0.3619
    


    
![png](output_30_2.png)
    


    [1m313/313[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 12ms/step
                  precision    recall  f1-score   support
    
     T-shirt/top       0.90      0.83      0.86      1000
         Trouser       0.99      0.97      0.98      1000
        Pullover       0.86      0.88      0.87      1000
           Dress       0.92      0.90      0.91      1000
            Coat       0.87      0.82      0.85      1000
          Sandal       0.98      0.99      0.99      1000
           Shirt       0.69      0.80      0.74      1000
         Sneaker       0.97      0.95      0.96      1000
             Bag       0.99      0.99      0.99      1000
      Ankle boot       0.97      0.97      0.97      1000
    
        accuracy                           0.91     10000
       macro avg       0.91      0.91      0.91     10000
    weighted avg       0.91      0.91      0.91     10000
    
    


    
![png](output_30_4.png)
    


## 7. Compare the two models


```python
comparison = pd.DataFrame(results).T.round(4)
display(comparison)

# Per-class F1 side by side, to see which classes improved
f1_base = f1_score(y_test, pred_base, average=None)
f1_imp  = f1_score(y_test, pred_imp,  average=None)
per_class = pd.DataFrame({"Baseline F1": f1_base, "Improved F1": f1_imp}, index=class_names).round(3)
display(per_class)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Test accuracy</th>
      <th>Macro F1</th>
      <th>Final train acc</th>
      <th>Final val acc</th>
      <th>Epochs run</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Baseline</th>
      <td>0.8956</td>
      <td>0.8963</td>
      <td>0.9413</td>
      <td>0.9031</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>Improved</th>
      <td>0.9106</td>
      <td>0.9117</td>
      <td>0.9144</td>
      <td>0.8832</td>
      <td>11.0</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Baseline F1</th>
      <th>Improved F1</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>T-shirt/top</th>
      <td>0.846</td>
      <td>0.863</td>
    </tr>
    <tr>
      <th>Trouser</th>
      <td>0.983</td>
      <td>0.985</td>
    </tr>
    <tr>
      <th>Pullover</th>
      <td>0.843</td>
      <td>0.869</td>
    </tr>
    <tr>
      <th>Dress</th>
      <td>0.903</td>
      <td>0.909</td>
    </tr>
    <tr>
      <th>Coat</th>
      <td>0.827</td>
      <td>0.848</td>
    </tr>
    <tr>
      <th>Sandal</th>
      <td>0.970</td>
      <td>0.986</td>
    </tr>
    <tr>
      <th>Shirt</th>
      <td>0.717</td>
      <td>0.739</td>
    </tr>
    <tr>
      <th>Sneaker</th>
      <td>0.943</td>
      <td>0.962</td>
    </tr>
    <tr>
      <th>Bag</th>
      <td>0.974</td>
      <td>0.987</td>
    </tr>
    <tr>
      <th>Ankle boot</th>
      <td>0.958</td>
      <td>0.969</td>
    </tr>
  </tbody>
</table>
</div>



```python
# Examples the improved model got wrong, to understand its remaining weaknesses
wrong = np.where(pred_imp != y_test)[0][:10]
plt.figure(figsize=(12, 5))
for i, idx in enumerate(wrong):
    plt.subplot(2, 5, i + 1)
    plt.imshow(x_test[idx].squeeze(), cmap='gray')
    plt.title(f"True: {class_names[y_test[idx]]}\nPred: {class_names[pred_imp[idx]]}", fontsize=8)
    plt.axis('off')
plt.tight_layout()
plt.show()
```


    
![png](output_33_0.png)
    

